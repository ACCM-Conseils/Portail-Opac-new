﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PortailsOpacBase.Portails.Diagnostique.Models
{
    public class Commune
    {
        public string numcom { get; set; }
        public string nomcom { get; set; }
    }
}