﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PortailsOpacBase.Portails.Diagnostique.Models
{
    public class Cible
    {
        public string adresse { get; set; }
        public string gbal { get; set; }
    }
}